package net.wanhe.edusystem.service;

public class TeaService {
}
