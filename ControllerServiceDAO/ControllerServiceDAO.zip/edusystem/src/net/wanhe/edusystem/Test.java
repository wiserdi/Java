package net.wanhe.edusystem;

import net.wanhe.edusystem.system.EduSystem;

public class Test {

    public static void main(String[] args) {
        EduSystem eduSystem = new EduSystem();
        eduSystem.run();
    }

}
