package net.wanhe.edusystem.controller;

public class TeaController {
}
