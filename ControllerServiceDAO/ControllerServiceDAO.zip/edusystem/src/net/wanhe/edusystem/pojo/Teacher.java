package net.wanhe.edusystem.pojo;

public class Teacher {
}
