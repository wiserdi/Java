package net.wanhe.edusystem.dao;

public class TeaDao {
}
