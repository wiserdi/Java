package net.wanhe.edusystem.system;

/*
 * 描述教师系统
 */
public class TeaSystem {
    public void run() {
    }
}
