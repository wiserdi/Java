package net.wanhe.edusystem.dao;

import net.wanhe.edusystem.pojo.Student;
import net.wanhe.edusystem.pojo.Teacher;

public class TeaDao {

    private Teacher[] teas = new Teacher[20];
    private int index = 0;

    //根据工号获得对应信息
    public Teacher findByNum(int num){
        for (int i = 0;i< index;i++){
            if(num == teas[i].getNum()){
                return teas[i];
            }
        }
        return null;
    }

    //添加老师
    public void addTea(Teacher tea){
        //当存放的数据数量和数组下标index一样是，需要对数组进行扩容
        if (index == teas.length){
            //创建一个新的数组
            Teacher[] newArray = new Teacher[teas.length+2];
            //将旧数组teas的值放到新数组去
            for (int i = 0;i<index;i++){
                newArray[i] =teas[i];
            }
            //将新数组地址赋值给teas
            teas = newArray;
            System.err.println("扩容成功");
        }
        teas[index++] = tea;
    }

    //删除老师
    public void delTea(int num){
        //找到需要删除的下标
        for (int i = 0; i <index ; i++){
            if (num == teas[i].getNum()){
                //这个i就是需要删除的下标
                for (int j = i;j<index-1;j++){
                    teas[i] = teas[i+1];
                }
                teas[(index--)-1] = null;
            }
        }
    }

    // 查询所有学生的信息
    public Teacher[] findAllTeas(){
        return teas;
    }
}
