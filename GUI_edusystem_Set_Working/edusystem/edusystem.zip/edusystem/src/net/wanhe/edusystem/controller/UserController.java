package net.wanhe.edusystem.controller;

import net.wanhe.edusystem.pojo.User;
import net.wanhe.edusystem.service.UserService;

import java.util.Scanner;

public class UserController {
    //展示登录注册的菜单
    //1.登录
    //2.注册
    //请选择：
    //注册（成功/失败）  +  登录失败  继续展示当前菜单
    //只有登录成功 展示管理菜单
    //注册  账号 + 密码 + 重复密码  （判断两次密码是否一致）（账号不能重复）
    //登录  账号 + 密码 （判断账号是否正确）  （判断密码是否一致）
    //User loginName passWord Userontroller UserService UserDao
    //运行登录注册系统

    private UserService userService = new UserService();

    private Scanner sc = new Scanner(System.in);

    //打印登录注册界面
    public int printMenu(){
        System.out.println("1.登录");
        System.out.println("2.注册");
        System.out.println("请选择：");
        int num = sc.nextInt();
        return num;
    }


    //登录功能
    public boolean userLogin(){
        boolean flag = true;
        System.out.println("请输入账户：");
        String num = sc.next();
        //userService.numJudge(num);
        System.out.println("请输入密码");
        String secret = sc.next();
        //userService.secJudge(secret);

        //将获取到的数据封装成对象
        User userlogin = new User(num,secret);
        return userService.userLogin(userlogin);
    }

    //注册功能
    public void userRegister(){
        System.out.println("请输入账户：");
        String num = sc.next();
        System.out.println("请输入密码");
        String secret = sc.next();
        System.out.println("请再次输入密码");
        String secret_2 = sc.next();

        //将获取到的数据封装成对象
        User userregister = new User(num,secret);
        userService.userRegister(userregister,secret,secret_2);

    }


}
