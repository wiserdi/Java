package net.wanhe.edusystem.service;

import net.wanhe.edusystem.dao.TeaDao;
import net.wanhe.edusystem.pojo.Teacher;

public class TeaService {
    private TeaDao teaDao = new TeaDao();

    //处理添加教师的业务逻辑
    public void addTeas( Teacher tea){

        //将工号给Dao,获取该学号对应的信息
        Teacher t = teaDao.findByNum(tea.getNum());
        if (t != null){
            System.out.println("该工号已被使用");
            return;
        }
        teaDao.addTea(tea);
        System.out.println("添加成功");

    }

    //处理删除老师的业务逻辑
    public void delTeas(int num){
        teaDao.delTea(num);
        System.out.println("删除成功");
    }
    //查询所有老师信息
    public Teacher[] findAllTeas(){
        Teacher[] teas = teaDao.findAllTeas();
        return teas;
    }
}
