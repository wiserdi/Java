package net.wanhe.edusystem;

import net.wanhe.edusystem.system.EduSystem;

public class Test {
    public static void main(String[] args) {
        EduSystem eduSystem = new EduSystem();
        eduSystem.run();
//        String magazine = new String("asd");
//        int[] cnt = new int[26];
//        for (char c : magazine.toCharArray()) {
//            cnt[c - 'a']++;
//            System.out.println(c-'a');

//        }
    }
}
