package net.wanhe.edusystem.pojo;

public class User {
    private String num;
    private String secret;
    public User(){}

    public User(String num, String secret) {
        this.num = num;
        this.secret = secret;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }
}
