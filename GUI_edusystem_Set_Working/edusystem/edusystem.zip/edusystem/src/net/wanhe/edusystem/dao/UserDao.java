package net.wanhe.edusystem.dao;

import net.wanhe.edusystem.pojo.User;

import javax.jws.soap.SOAPBinding;

public class UserDao {

    private int index = 0;
    private User[] users = new User[20];

    //通过输入的账号寻找对应的账号密码
    public User findByNum(String num){
        for (int i = 0 ;i<index;i++){
            if (users[i].equals(num)){
                return users[i];
            }
        }
        return null;
    }
    public void adduser(User user){
        //如果存放数据数量等于数组容量 进行扩容操作
        if (index ==users.length){
            //定义一个新的数组
            User[] newArray = new User[users.length+2];
            //通过循环存放转移数组里的对象
            for (int i = 0; i<index;i++){
                newArray[i] = users[i];
            }
            //将新数组的地址赋给旧数组
            users = newArray;
            System.out.println("扩容成功");
        }

        //将对象user存放到数组中
        users[index++] = user;
    }

}
