package net.wanhe.edusystem.service;

import net.wanhe.edusystem.dao.UserDao;
import net.wanhe.edusystem.pojo.User;

import java.util.Scanner;

public class UserService {

    //展示登录注册的菜单
    //1.登录
    //2.注册
    //请选择：
    //注册（成功/失败）  +  登录失败  继续展示当前菜单
    //只有登录成功 展示管理菜单
    //注册  账号 + 密码 + 重复密码  （判断两次密码是否一致）（账号不能重复）
    //登录  账号 + 密码 （判断账号是否正确）  （判断密码是否一致）
    //User loginName passWord Userontroller UserService UserDao
    //运行登录注册系统
    private Scanner sc = new Scanner(System.in);
    private UserDao userDao = new UserDao();


    public boolean userLogin(User user){
        //处理业务逻辑
        //1.判断账号是否正确
        //将账号给Dao 获取该账号的信息
        User u = userDao.findByNum(user.getNum());
        if (u != null){
            System.out.println("账号正确，请输入密码");
        }else{
            System.out.println("账号错误，请创建账号");
            return true;
        }
        //2.判断密码是否一致
        String secret = sc.next();
        int index = 1;
        boolean flag = true;
        while(flag){
            if (secret == u.getSecret() && index !=4){
                System.out.println("登录成功");
                flag = false;
                continue;
            }else if ( index == 4){
                System.out.println("登陆失败");
                flag = false;
                return true;
            }else if(secret != u.getSecret() && index!=4){
                System.out.println("密码不一致，请重新输入");
                secret = sc.next();
                index++;
            }
        }
        return false;
    }

    public void userRegister(User user, String secret, String secret_2){
        //处理业务逻辑
        //1.判断账号是否已被使用
        User u = userDao.findByNum(user.getNum());
        if (u != null){
            System.out.println("该账号已被使用");
            return;
        }
        System.out.println("该账号可以使用");

        //2.判断密码是否符合要求
        if (secret.length() < 8){
            System.out.println("密码长度必须大于8");
            System.out.println("创建失败");
            return;
        }

        //3.重复输入密码判断密码是否一致
        if (secret.equals(secret_2)){
            System.out.println("密码一致");
        }else {
            System.out.println("密码不一致,请重新创建");
            return;
        }

        //4.添加账号信息给 Dao
        userDao.adduser(user);

        //5.提示注册成功
        System.out.println("注册成功");
        return;
    }
}
